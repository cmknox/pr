//
//  Copyright (c) Microsoft Corporation. All rights reserved.
//

#import "CDCommon.h"

typedef NS_ENUM(NSInteger, CDRemoteSystemKind) {
    CDRemoteSystemKindUnknown = 0,
    CDRemoteSystemKindDesktop,
    CDRemoteSystemKindHolographic,
    CDRemoteSystemKindPhone,
    CDRemoteSystemKindXbox,
    CDRemoteSystemKindHub
};

/**
 * @brief Returns string representation for a Remote System Kind.
 * @param CDRemoteSystemKind The kind.
 * @returns String representation.
 */
__CD_VISIBLE_EXTERNALLY
NSString* CDRemoteSystemFriendlyNameForKind(CDRemoteSystemKind type);