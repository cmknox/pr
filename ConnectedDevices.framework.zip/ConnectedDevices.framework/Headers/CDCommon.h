//
//  Copyright (c) Microsoft Corporation. All rights reserved.
//

#define __CD_VISIBLE_EXTERNALLY __attribute__((visibility("default")))
